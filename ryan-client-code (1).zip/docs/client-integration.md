# Client integration notes (ClientController, ClientState, RemoteData, MessageView, main.js)

Owner: Ryan. What the client controller expects from the views, the page and the server.

## Tests

Node 22 or newer, no `npm install` needed:

```
npm test            # all client tests
npm run coverage    # tests plus a coverage table
```

`src/test/js/main.test.js` drives `main.js` with fake views that have exactly
the interface below, so it checks the wiring without a browser.

## index.html

Copy `dev.html` to `index.html` and replace the dev script with:

```html
<script type="module" src="js/main.js"></script>
```

`main.js` looks up these element ids (`ELEMENT_IDS` at the top of `main.js`).
Either give the elements these ids, or change `ELEMENT_IDS` to the ids in `dev.html`:

| Key | Default id | Element |
|---|---|---|
| map | `map` | map container (full screen) |
| panel | `panel` | bottom panel; `data-screen` is set to `plan` or `detail` |
| home | `home` | HomeView container |
| comparison | `routes` | RouteComparisonView container |
| detail | `route-detail` | RouteDetailView container |
| messages | `messages` | MessageView container |
| footer | `footer` | footer (data version) |

`main.js` stops with an error naming every missing id. It also keeps
`MapView.setBottomInset` equal to the panel's height (ResizeObserver).

## Views (Yuki's interface, as used by main.js)

| View | main.js calls | main.js listens to |
|---|---|---|
| HomeView(container) | `render()` once, `setPlaces([{id, label}])`, `setValues({origin, destination})`, `showFieldErrors([{field, problem}])` | `onSearch`, `onChange`: both receive `{origin, destination, departure, maxExtraMinutes}` (missing fields are kept) |
| MapView(container) | `renderMap(mapData)`, `renderRoute(segments)`, `highlightSegments(edgeIds)`, `setSelected({origin, destination})`, `setBottomInset(px)` | `onPlaceClick(id)` |
| RouteComparisonView(container) | `render(result)`, `render(null)` to clear, `setSelected(kind)` (`null` when there are no options) | `onSelect(kind)`, `onEditTrip()` |
| RouteDetailView(container) | `render(option)`, `setSelectedStep(i)` (`null` clears) | `onStepSelect(i)`, `onBack()` |
| MessageView(container, footer) | `showLoading(text)`, `showError(text, {retry})`, `showInfo(text)`, `hide()`, `setDataVersion(v)` | `onRetry()` |

Screens: after a search the panel shows `plan` (form plus comparison) with the
fastest option selected and drawn. Choosing a card opens `detail`; Back returns
to `plan`. Edit trip removes the result and keeps the form values. Changing the
form or clicking a place while a search is running abandons that search.

Data shapes passed to the views (the shapes of architecture §3):

- `renderMap`: `{map: {imageUrl, imageWidth, imageHeight}, buildings: [{id, name, outline: [[x, y], …]}], places: [{id, label, xNorm, yNorm}]}`
- `render(result)`: `{dataVersion, status, identical, options}`; `status` is `COMPLETE`, `NO_FEASIBLE_ROUTE` or `INCOMPLETE`
- option: `{kind, optimal, distanceM, walkSeconds, exposedM, extraSeconds, exposureReductionM, segments, steps}`
- segment: `{edgeId, cover: 'indoor' | 'covered' | 'outdoor', points: [[x, y], …]}`; step: `{text, edgeIds}`

If a view expects another shape, change only the `toView…` functions in `main.js`.

## Server API (Leon, Stark)

`GET /api/meta`, `GET /api/map`, `POST /api/routes` (architecture §3).

- Every response includes `dataVersion`. A route result with a different version
  from the map makes the client reload the map and re-send the query once.
- Coordinates may be `xNorm`/`yNorm` or `x_norm`/`y_norm`; points `[x, y]` or
  `{xNorm, yNorm}`; cover in any case.
- `label` should be a plain string. For `Optional<String>`, register Jackson's
  `Jdk8Module`; otherwise the client shows the id instead of the label.
- Validation errors: HTTP 400 with
  `{"dataVersion": "...", "error": {"code": "VALIDATION_ERROR", "fields": [{"field": "...", "problem": "..."}]}}`.
- Any other non-2xx status, invalid JSON, a timeout (15 s) or a response that
  breaks the contract is shown as "Service error, please retry", never as "no route".
