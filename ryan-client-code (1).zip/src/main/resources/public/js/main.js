import { ClientController } from './controller/ClientController.js';
import { MessageView } from './views/MessageView.js';
import { HomeView } from './views/HomeView.js';
import { MapView } from './views/MapView.js';
import { RouteComparisonView } from './views/RouteComparisonView.js';
import { RouteDetailView } from './views/RouteDetailView.js';

/**
 * Page entry point: builds the views, connects them to ClientController and
 * starts the app. index.html loads it with
 *   <script type="module" src="js/main.js"></script>
 *
 * This is the only file that knows both the controller's UiPort and the views'
 * own methods (Yuki's view interface). If a view's methods or the data shape a
 * view expects change, adjust this file; ClientController does not change.
 */

/**
 * Ids of the page elements. They must match index.html (which follows the
 * structure of dev.html). `panel` is the bottom panel whose data-screen
 * attribute switches between "plan" and "detail".
 */
export const ELEMENT_IDS = Object.freeze({
    map: 'map',
    panel: 'panel',
    home: 'home',
    comparison: 'routes',
    detail: 'route-detail',
    messages: 'messages',
    footer: 'footer',
});

/**
 * @precondition none
 * @postcondition returns the elements named in ELEMENT_IDS
 * @param {Document} doc
 * @returns {Record<string, HTMLElement>}
 * @throws {Error} naming every missing id
 */
function findElements(doc) {
    const missing = Object.values(ELEMENT_IDS).filter((id) => doc.getElementById(id) === null);
    if (missing.length > 0) {
        throw new Error(`index.html is missing elements with id: ${missing.join(', ')}`);
    }
    return Object.fromEntries(Object.entries(ELEMENT_IDS).map(([key, id]) => [key, doc.getElementById(id)]));
}

// ---------------------------------------------------------------- data shapes for the views
// ClientState stores points as {xNorm, yNorm}. The views follow the examples in
// architecture §3 and the files in data/, where a point is [x, y]. All shape
// conversion for the views happens here.

const toPair = (p) => [p.xNorm, p.yNorm];

/** Map data in the shape of GET /api/map (without dataVersion, which MessageView shows). */
export function toViewMap(mapData, places) {
    return {
        map: { ...mapData.map },
        buildings: mapData.buildings.map((b) => ({ id: b.id, name: b.name, outline: b.outline.map(toPair) })),
        places: places.map((p) => ({ id: p.id, label: p.label, xNorm: p.xNorm, yNorm: p.yNorm })),
    };
}

export function toViewSegments(segments) {
    return segments.map((s) => ({ edgeId: s.edgeId, cover: s.cover, points: s.points.map(toPair) }));
}

export function toViewOption(option) {
    return { ...option, segments: toViewSegments(option.segments), steps: option.steps.map((s) => ({ ...s })) };
}

/** Route result in the shape of the POST /api/routes response. */
export function toViewResult(result) {
    return { ...result, options: result.options.map(toViewOption) };
}

/**
 * Adapts Yuki's views to the controller's UiPort.
 * @precondition views and elements come from start()
 * @postcondition returns an object implementing UiPort
 */
function createUi(views, elements) {
    return {
        renderHome(places) {
            views.home.setPlaces(places.map((p) => ({ id: p.id, label: p.label })));
        },
        showSelectedEndpoints(endpoints) {
            views.home.setValues({ origin: endpoints.origin, destination: endpoints.destination });
            views.map.setSelected({ origin: endpoints.origin, destination: endpoints.destination });
        },
        showFieldErrors(errors) {
            views.home.showFieldErrors(errors.map((e) => ({ field: e.field, problem: e.problem })));
        },
        renderMap(mapData, places) {
            views.map.renderMap(toViewMap(mapData, places));
        },
        renderRoutes(result) {
            views.comparison.render(toViewResult(result));
        },
        setSelectedOption(kind) {
            views.comparison.setSelected(kind);
        },
        renderRouteDetail(option) {
            views.detail.render(toViewOption(option));
        },
        setSelectedStep(index) {
            views.detail.setSelectedStep(index);
        },
        drawRoute(segments) {
            views.map.renderRoute(toViewSegments(segments));
        },
        highlightEdges(edgeIds) {
            views.map.highlightSegments([...edgeIds]);
        },
        clearRoutes() {
            views.map.renderRoute([]);
            views.map.highlightSegments([]);
            views.comparison.render(null);
        },
        showScreen(screen) {
            elements.panel.dataset.screen = screen;
        },
        setBusy(busy) {
            elements.panel.toggleAttribute('aria-busy', busy);
        },
        onSearch: (handler) => views.home.onSearch(handler),
        onFormChange: (handler) => views.home.onChange(handler),
        onPlaceClick: (handler) => views.map.onPlaceClick(handler),
        onSelectOption: (handler) => views.comparison.onSelect(handler),
        onSelectStep: (handler) => views.detail.onStepSelect(handler),
        onBack: (handler) => views.detail.onBack(handler),
        onEditTrip: (handler) => views.comparison.onEditTrip(handler),
    };
}

/**
 * Keeps the map's bottom inset equal to the panel's height, so the panel
 * never covers the part of the map the user is looking at.
 */
function trackPanelHeight(panel, mapView) {
    const update = () => mapView.setBottomInset(Math.round(panel.getBoundingClientRect().height));
    update();
    if (typeof ResizeObserver === 'function') {
        new ResizeObserver(update).observe(panel);
    }
}

const VIEW_CLASSES = Object.freeze({ HomeView, MapView, RouteComparisonView, RouteDetailView, MessageView });

/**
 * Starts the application.
 * @precondition the DOM is loaded and contains the elements in ELEMENT_IDS;
 *   classes (for tests) provide the five view classes
 * @postcondition the views are built, the controller is running and the
 *   initial data has been requested
 * @param {Document} [doc]
 * @param {Object} [classes]
 * @param {Object} [controllerOptions] extra ClientController dependencies (for tests)
 * @returns {Promise<ClientController>}
 */
export async function start(doc = document, classes = VIEW_CLASSES, controllerOptions = {}) {
    const elements = findElements(doc);
    const views = {
        home: new classes.HomeView(elements.home),
        map: new classes.MapView(elements.map),
        comparison: new classes.RouteComparisonView(elements.comparison),
        detail: new classes.RouteDetailView(elements.detail),
    };
    views.home.render();
    const messages = new classes.MessageView(elements.messages, elements.footer);

    const controller = new ClientController({ ui: createUi(views, elements), messages, ...controllerOptions });
    trackPanelHeight(elements.panel, views.map);
    await controller.init();
    return controller;
}

if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => { start(); });
    } else {
        start();
    }
}
